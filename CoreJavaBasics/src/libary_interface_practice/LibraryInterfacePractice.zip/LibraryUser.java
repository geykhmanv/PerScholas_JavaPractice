package libary_interface_practice;

public interface LibraryUser {

	public void registerAccount();
	public void requestBook();
	
	
}//public interface LibraryUser
